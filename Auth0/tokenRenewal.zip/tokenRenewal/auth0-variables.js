var AUTH0_CLIENT_ID='scxSRJNVt1OFdJonoJEnzJ7NR2PhHnfj';
var AUTH0_DOMAIN='terumobct-ext-dev.auth0.com';
var AUTH0_CALLBACK_URL=location.href;

